<?php
  $host ="localhost"; //host server
  $user ="id21053724_root"; //user login phpMyAdmin
  $pass ="Closeyoureyes21_"; //pass login phpMyAdmin
  $db ="id21053724_tapera"; //nama database
  $conn = mysqli_connect($host, $user, $pass, $db) or die ("Koneksi gagal");
